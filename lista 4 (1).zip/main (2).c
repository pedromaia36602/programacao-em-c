/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    float num1, num2, num3;
    while (num1!=0&&num2!=0&&num3!=0){
        printf ("digite 3 numeros ou 0 para sair ");
        scanf ("%f%f%f",&num1,&num2,&num3);
        if (num1>num2 && num1>num3)
            printf ("%f e o maior ",num1);
        else if (num2>num1 && num2>num3)
            printf ("%f e o maior ",num2);
        else if (num3>num1 && num3>num2)
            printf ("%f e o maior ",num3);
        else if (num1 == num2 && num1==num3)
            printf ("os numeros sao iguais ");
        else if (num1==num2||num1==num3||num2==num3)
            printf ("alguns dos numeros sao iguais ");
    }
    
    return 0;
}
