/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    float peso, altura, imc;
    printf("digite a sua altura e peso");
    scanf("%f%f",&altura,&peso);
    imc = peso / (altura*altura);
    if(imc<=18.5)
        printf("imc = %.2f abaixo do peso",imc);
    else if(imc>=18,50&&imc<=24.49)
        printf("imc = %f peso normal",imc);
    else if(imc>=25&&imc<=29.99)
        printf("imc = %f acima do peso",imc);
    else if(imc>=30&&imc<=34.99)
        printf("imc = %fobesidade grau 1",imc);
    else if(imc>=35&&imc<=39.99) 
        printf("imc = %f obesidade grau 2",imc);
    else if(imc<40)
           printf("imc = %f obesidade grau 3",imc);
}