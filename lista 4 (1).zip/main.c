/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    float num;
    while (num>0){
        printf ("digite  numero para ver se ele esta entre 20 e 50 ou digite 0 para sair");
        scanf ("%f",&num);
        if (num >=20 && num<=50)
            printf ("%f esta entre 20 e 50",num);
        else
            printf ("%f nao esta entre 20 e 50",num);}

    return 0;
}
