/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int ano, idade, anoatual;
    while (ano>0){
        printf ("digite o ano atual e o ano do seu nascimento e 0 para sair");
        scanf ("%d%d",&anoatual,&ano);
        if (ano<1900)
            printf ("digite um ano valido");
        else{
            idade = anoatual - ano;
            printf ("sua idade e: %d",idade);}
    }
    
    return 0;
}
