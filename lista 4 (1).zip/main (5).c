#include <stdio.h>

int main()
{   
    float peso, alt;
    printf("digite o peso e altura para classificacao: \n");
    scanf("%f%f",&peso,&alt);
    if(peso<=60 && alt<1.20)
        printf("classificacao A");
    else if(peso<=60 && alt>=1.20 || alt<=1.70)
        printf("classificacao B");
    else if(peso<=60 && alt>1.70)
        printf("classificacao C");
    else if(peso>60 || peso<=90 && alt<1.20)
        printf("classificacao D");
    else if(peso>60 || peso<=90 && alt>=1.20 || alt<=1.70)
        printf("classificacao E");
    else if(peso>60 || peso<=90 && alt>1.70)
        printf("classificacao F");
    else if(peso>90 && alt<1.20)
        printf("classificacao G");
    else if(peso>90 && alt>=1.20 || alt<=1.70)
        printf("classificacao H");
    else if(peso>90 && alt>1.70)
        printf("classificacao I");
    
return 0;
}