/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    float notatrab1,notatrab2,notaprova1,notaprova2,faltas,notafinal;
    printf("digite a nota do trabalho 1, trabalho 2, prova 1, prova 2 e faltas");
    scanf ("%f%f%f%f%f",&notatrab1,&notatrab2,&notaprova1,&notaprova2,&faltas);
    notafinal=((notaprova1*0.6)+(notaprova2*0.6)+(notatrab1*0.4)+(notatrab2*0.4))/2;
    if (notafinal<4||faltas>80*0.75)
        printf ("reprovado, nota: %2f, faltas: %1f ",notafinal,faltas);
    else if (notafinal>=4 && notafinal<6)
        printf ("recuperacao, nota: %2f, faltas: %1f ",notafinal,faltas);
    else if (notafinal >=6)
        printf ("aprovado, nota: %2f, faltas: %1f ",notafinal,faltas);
        
    return 0;
}
